const hotels = [
 {id:1,name:"Azure Coast Resort",city:"antalya",location:"Antalya • Lara",rating:9.2,reviews:418,price:4850,desc:"Denize yakın, modern odalar ve geniş havuz alanı.",image:"https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=1000&q=85"},
 {id:2,name:"Bodrum Marina Hotel",city:"bodrum",location:"Bodrum • Merkez",rating:9.0,reviews:263,price:6250,desc:"Marina manzarası, merkezi konum ve seçkin restoran.",image:"https://images.unsplash.com/photo-1601918774946-25832a4be0d6?auto=format&fit=crop&w=1000&q=85"},
 {id:3,name:"Alaçatı Stone House",city:"cesme",location:"Çeşme • Alaçatı",rating:9.4,reviews:192,price:3950,desc:"Taş mimari, sakin avlu ve Alaçatı atmosferi.",image:"https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1000&q=85"},
 {id:4,name:"Cappadocia Valley Cave",city:"kapadokya",location:"Kapadokya • Göreme",rating:9.5,reviews:331,price:5400,desc:"Vadiler arasında benzersiz mağara oda deneyimi.",image:"https://images.unsplash.com/photo-1573053986275-840ffc7cc685?auto=format&fit=crop&w=1000&q=85"},
 {id:5,name:"Mediterranean Palace",city:"antalya",location:"Antalya • Belek",rating:8.9,reviews:510,price:7200,desc:"Geniş tesis, özel plaj ve aile dostu olanaklar.",image:"https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1000&q=85"},
 {id:6,name:"Bodrum Blue Suites",city:"bodrum",location:"Bodrum • Yalıkavak",rating:9.1,reviews:174,price:8150,desc:"Sade lüks, Ege manzarası ve özel süitler.",image:"https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1000&q=85"},
 {id:7,name:"Istanbul Bosphorus Stay",city:"istanbul",location:"İstanbul • Beşiktaş",rating:9.0,reviews:642,price:4600,desc:"Boğaz hattında şehir kaçamağı için modern konaklama.",image:"https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1000&q=85"},
 {id:8,name:"Çeşme Seaside Club",city:"cesme",location:"Çeşme • Ilıca",rating:8.8,reviews:229,price:5750,desc:"Plaja yakın konum ve Ege yazı için rahat odalar.",image:"https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=1000&q=85"}
];

let favorites = JSON.parse(localStorage.getItem("yc_favorites") || "[]");
let currentHotels = [...hotels];

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const money = n => new Intl.NumberFormat("tr-TR",{style:"currency",currency:"TRY",maximumFractionDigits:0}).format(n);

function toast(message){
 const el=$("#toast"); el.textContent=message; el.classList.add("show");
 clearTimeout(window.toastTimer); window.toastTimer=setTimeout(()=>el.classList.remove("show"),2800);
}
function saveFav(){localStorage.setItem("yc_favorites",JSON.stringify(favorites)); updateFavCount();}
function updateFavCount(){$("#favCount").textContent=favorites.length;}
function isFav(id){return favorites.includes(id)}

function renderHotels(list=hotels){
 currentHotels=list;
 const grid=$("#hotelGrid"), empty=$("#emptyHotels");
 grid.innerHTML="";
 empty.hidden=list.length!==0;
 list.forEach(h=>{
   const card=document.createElement("article"); card.className="hotel-card";
   card.innerHTML=`
    <div class="hotel-img" style="background-image:url('${h.image}')">
      <button class="heart ${isFav(h.id)?"active":""}" data-fav="${h.id}" aria-label="Favoriye ekle">${isFav(h.id)?"♥":"♡"}</button>
      <span class="rating">★ ${h.rating} <small>(${h.reviews})</small></span>
    </div>
    <div class="hotel-body">
      <span class="hotel-location">${h.location}</span><h3>${h.name}</h3><p>${h.desc}</p>
      <div class="hotel-bottom">
        <div class="price"><strong>${money(h.price)}</strong><small> / gece</small></div>
        <div class="hotel-actions"><button class="small-btn" data-detail="${h.id}">Detay</button><button class="small-btn primary" data-book="${h.id}">Rezervasyon</button></div>
      </div>
    </div>`;
   grid.appendChild(card);
 });
 $$("[data-fav]").forEach(b=>b.addEventListener("click",()=>toggleFav(Number(b.dataset.fav))));
 $$("[data-detail]").forEach(b=>b.addEventListener("click",()=>openHotel(Number(b.dataset.detail))));
 $$("[data-book]").forEach(b=>b.addEventListener("click",()=>openBooking(Number(b.dataset.book))));
}

function toggleFav(id){
 favorites=isFav(id)?favorites.filter(x=>x!==id):[...favorites,id];
 saveFav(); renderHotels(currentHotels);
 toast(isFav(id)?"Otel favorilere eklendi.":"Favorilerden çıkarıldı.");
}
function openModal(html){$("#modalContent").innerHTML=html;$("#modal").classList.add("open");$("#modal").setAttribute("aria-hidden","false")}
function closeModal(){$("#modal").classList.remove("open");$("#modal").setAttribute("aria-hidden","true")}
function openHotel(id){
 const h=hotels.find(x=>x.id===id);
 openModal(`<div style="height:220px;border-radius:12px;background:url('${h.image}') center/cover"></div>
 <span class="eyebrow blue">${h.location}</span><h2>${h.name}</h2><p>${h.desc}</p>
 <div class="booking-summary"><b>★ ${h.rating}</b> · ${h.reviews} değerlendirme<br><strong>${money(h.price)}</strong> / gece</div>
 <button class="primary-btn" data-modal-book="${h.id}">Bu oteli rezerve et</button>`);
 $("[data-modal-book]").addEventListener("click",()=>openBooking(id));
}
function openBooking(id){
 const h=hotels.find(x=>x.id===id);
 openModal(`<h2>Rezervasyon talebi</h2><p>${h.name}</p>
 <div class="booking-summary"><b>${h.location}</b><br>${money(h.price)} / gece</div>
 <form class="booking-form" id="bookingForm">
 <label>Ad Soyad<input id="bookName" required placeholder="Adınız Soyadınız"></label>
 <label>E-posta<input id="bookEmail" type="email" required placeholder="ornek@mail.com"></label>
 <label>Telefon<input id="bookPhone" type="tel" required placeholder="+90"></label>
 <label>Giriş<input id="bookIn" type="date" required></label>
 <label>Çıkış<input id="bookOut" type="date" required></label>
 <label>Misafir<select id="bookGuests"><option>1</option><option selected>2</option><option>3</option><option>4</option><option>5</option><option>6+</option></select></label>
 <button class="primary-btn" type="submit">Rezervasyon talebi gönder</button>
 </form>`);
 $("#bookingForm").addEventListener("submit",e=>{
   e.preventDefault();
   const inDate=new Date($("#bookIn").value), outDate=new Date($("#bookOut").value);
   if(!(outDate>inDate)){toast("Çıkış tarihi giriş tarihinden sonra olmalı.");return}
   const request={hotel:h.name,name:$("#bookName").value,email:$("#bookEmail").value,phone:$("#bookPhone").value,checkin:$("#bookIn").value,checkout:$("#bookOut").value,guests:$("#bookGuests").value};
   localStorage.setItem("yc_last_booking",JSON.stringify(request));
   openModal(`<div style="text-align:center;padding:15px"><div style="font-size:48px">✓</div><h2>Talebiniz alındı</h2><p>Demo rezervasyon talebiniz bu cihazda kaydedildi. Gerçek rezervasyon için işletmenin backend/API bağlantısı eklenmelidir.</p><button class="primary-btn" data-close>Sayfaya dön</button></div>`);
   toast("Rezervasyon talebi kaydedildi.");
 });
}

function applyFilter(city){
 const list=city==="all"?hotels:hotels.filter(h=>h.city===city);
 $$(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter===city));
 renderHotels(list);
}
$("#searchForm").addEventListener("submit",e=>{
 e.preventDefault();
 const city=$("#destination").value;
 const ci=$("#checkin").value, co=$("#checkout").value;
 if(new Date(co)<=new Date(ci)){toast("Çıkış tarihi giriş tarihinden sonra olmalı.");return}
 applyFilter(city);
 document.querySelector("#oteller").scrollIntoView({behavior:"smooth"});
 toast(`${city==="all"?"Tüm":city[0].toUpperCase()+city.slice(1)} seçenekleri gösteriliyor.`);
});
$$(".filter").forEach(b=>b.addEventListener("click",()=>applyFilter(b.dataset.filter)));
$$(".destination-card").forEach(b=>b.addEventListener("click",()=>{
 $("#destination").value=b.dataset.destination; applyFilter(b.dataset.destination);
 document.querySelector("#oteller").scrollIntoView({behavior:"smooth"});
}));
$("#showAllHotels").addEventListener("click",()=>{applyFilter("all");document.querySelector("#oteller").scrollIntoView({behavior:"smooth"})});
$("#favoritesBtn").addEventListener("click",()=>{
 const list=hotels.filter(h=>favorites.includes(h.id));
 renderHotels(list);
 document.querySelector("#oteller").scrollIntoView({behavior:"smooth"});
 toast(list.length?`${list.length} favori otel gösteriliyor.`:"Henüz favori oteliniz yok.");
});
$$(".tour-open").forEach(b=>b.addEventListener("click",()=>{
 openModal(`<span class="eyebrow blue">TUR PROGRAMI</span><h2>${b.dataset.tour}</h2><p>Bu tur için tarih, kişi sayısı ve özel taleplerinizi iletişim formu üzerinden iletebilirsiniz.</p><div class="booking-summary">✓ Program bilgisi<br>✓ Konaklama seçeneği<br>✓ Ulaşım planlaması<br>✓ Destinasyon danışmanlığı</div><a class="primary-btn" href="#iletisim" data-close>Tur hakkında bilgi al</a>`);
}));
$("#contactForm").addEventListener("submit",e=>{
 e.preventDefault();
 localStorage.setItem("yc_contact",JSON.stringify({name:$("#contactName").value,email:$("#contactEmail").value,message:$("#contactMessage").value}));
 e.target.reset(); toast("Mesajınız demo olarak kaydedildi.");
});
$("#privacyBtn").addEventListener("click",()=>openModal(`<h2>Gizlilik Bilgilendirmesi</h2><div class="privacy-box"><p>Bu demo sitede form verileri sunucuya gönderilmez; rezervasyon ve iletişim formu bilgileri yalnızca bu tarayıcının localStorage alanında tutulur.</p><p>Gerçek yayına geçmeden önce şirket bilgileri, KVKK aydınlatma metni, çerez politikası, mesafeli satış/rezervasyon şartları ve gerekli yasal metinler profesyonel olarak hazırlanmalıdır.</p></div>`));
$("#modal").addEventListener("click",e=>{if(e.target.matches("[data-close],.modal-backdrop"))closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
$("#menuToggle").addEventListener("click",()=>$("#mainNav").classList.toggle("open"));
$$("nav a").forEach(a=>a.addEventListener("click",()=>$("#mainNav").classList.remove("open")));
window.addEventListener("scroll",()=>$("#scrollTop").classList.toggle("show",scrollY>500));
$("#scrollTop").addEventListener("click",()=>scrollTo({top:0,behavior:"smooth"}));

const today=new Date(); const tomorrow=new Date(today); tomorrow.setDate(today.getDate()+1); const dayAfter=new Date(today); dayAfter.setDate(today.getDate()+3);
const iso=d=>d.toISOString().slice(0,10);
$("#checkin").value=iso(tomorrow);$("#checkout").value=iso(dayAfter);$("#checkin").min=iso(today);$("#checkout").min=iso(tomorrow);
$("#checkin").addEventListener("change",()=>{$("#checkout").min=$("#checkin").value; if($("#checkout").value<=$("#checkin").value)$("#checkout").value="";});
$("#year").textContent=new Date().getFullYear();
updateFavCount(); renderHotels();
