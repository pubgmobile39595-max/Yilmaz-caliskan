# Yılmaz Çalışkan Turizm

GitHub Pages uyumlu, statik turizm/rezervasyon arayüzü.

## Dosyalar
- `index.html` — site yapısı
- `style.css` — tasarım ve responsive görünüm
- `script.js` — arama, filtreleme, favoriler, modal detayları ve demo rezervasyon akışı

## GitHub Pages
1. GitHub'da yeni bir repository oluştur.
2. Bu üç dosyayı repository'nin ana dizinine yükle.
3. `Settings > Pages` bölümüne gir.
4. `Deploy from a branch` seç.
5. Branch olarak `main`, klasör olarak `/ (root)` seç.
6. Save de.
7. GitHub'ın verdiği Pages adresini aç.

## Önemli
Bu sürüm gerçek otel envanterine veya ödeme sistemine bağlı değildir. Fiyatlar ve otel içerikleri demo verisidir.
Gerçek rezervasyon, ödeme, kullanıcı hesabı, canlı müsaitlik ve şirket bilgileri için backend/API ve gerçek işletme bilgileri eklenmelidir.
